<template>
  <div class="draw-point">
    point
  </div>
</template>

<script>
export default {};
</script>

<style></style>
