<template>
  <div class="draw-polygon">
    polygon
  </div>
</template>

<script>
export default {};
</script>

<style></style>
