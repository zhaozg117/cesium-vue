<template>
  <div class="plotting">
    <h1>sdfsdf</h1>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
