<template>
  <div class="draw-polyline">
    polyline
  </div>
</template>

<script>
export default {};
</script>

<style></style>
